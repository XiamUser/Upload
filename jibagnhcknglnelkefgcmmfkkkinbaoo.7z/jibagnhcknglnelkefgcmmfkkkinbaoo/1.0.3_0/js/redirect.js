var _chromeVer = window.navigator.userAgent.match(/chrome\/([\d.]+)/i);
var chromeVer = _chromeVer != null ? _chromeVer[1] : _chromeVer;
try{
	chrome.tabs.getCurrent(function(tab) {		
		chrome.tabs.update(tab.id, {
			"url": (chromeVer != null &&  chromeVer > '33') ? "chrome-search://local-ntp/local-ntp.html" : "chrome-internal://newtab/",
			"selected": true
		});
	});
}catch(e){
	window.location = (chromeVer != null &&  chromeVer > '33') ? "chrome-search://local-ntp/local-ntp.html" : "chrome-internal://newtab/";
}