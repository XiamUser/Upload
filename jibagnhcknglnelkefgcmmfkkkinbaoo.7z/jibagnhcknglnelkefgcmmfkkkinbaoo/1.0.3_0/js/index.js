document.title = chrome.i18n.getMessage("chrome_extension_name");
document.write('<FRAMESET border="0" frameSpacing="0" cols="0%,100%">\
					<FRAME src="about:blank" name="left" id="left" scrolling="no"></FRAME>\
					<FRAME src="http://' + (chrome.i18n.getMessage("@@ui_locale") == "zh_CN" ? "cn" : "www") + '.newmetrotab.com/?extId=' + window.location.host + '&t=' + new Date().getTime() + '" name="main" scrolling="no"></FRAME>\
				</FRAMESET>\
				<noframes></noframes>');